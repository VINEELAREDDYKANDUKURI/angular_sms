package com.student.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;

@Entity
@Table(name = "Student_Management")
public class student {
   @Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "student_id")
    private Long studentId;
    @NotBlank(message = "Name is required")
    @Column(name = "name", nullable = false)
   private String name;
    @NotNull(message = "Date of Birth is required")
    @Column(name = "dob", nullable = false)
   private LocalDate dob;
   @NotBlank(message = "Class is required")
  @Column(name = "class_name", nullable = false) // 'class' is reserved in Java
    private String className;
  @NotBlank(message = "Division is required")
   @Column(name = "division", nullable = false)
   private String division;
   @Column(name = "subject", columnDefinition = "VARCHAR(255) DEFAULT 'Science Maths'")
   private String subject = "Science Maths";
   @NotBlank(message = "Address is required")
   @Column(name = "address", nullable = false)
   private String address;
   @Column(name = "is_deleted", columnDefinition = "BOOLEAN DEFAULT false")
   private Boolean isDeleted = false;
   public student() {}
   public student(String name, LocalDate dob, String className, String division,
                   String subject, String address) {
        this.name = name;
        this.dob = dob;
        this.className = className;
        this.division = division;
        this.subject = (subject != null && !subject.isEmpty()) ? subject : "Science Maths";
        this.address = address;
       this.isDeleted = false;
       }
    public Long getStudentId() { return studentId; }
    public void setStudentId(Long studentId) { this.studentId = studentId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public LocalDate getDob() { return dob; }
    public void setDob(LocalDate dob) { this.dob = dob; }
    public String getClassName() { return className; }
    public void setClassName(String className) { this.className = className; }
    public String getDivision() { return division; }
    public void setDivision(String division) { this.division = division; }
    public String getSubject() { return subject; }
    public void setSubject(String subject) { this.subject = subject; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public Boolean getIsDeleted() { return isDeleted; }
    public void setIsDeleted(Boolean isDeleted) { this.isDeleted = isDeleted; }
}