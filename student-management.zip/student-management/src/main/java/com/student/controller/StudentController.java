package com.student.controller;
import com.student.entity.student;
import com.student.service.StudentService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
@RestController
@RequestMapping("/students")
@CrossOrigin(origins = "*") 
public class StudentController {
    @Autowired
    private StudentService studentService;
    @PostMapping
    public ResponseEntity<Map<String, Object>> addStudent(@Valid @RequestBody student student) {
        student saved = studentService.addStudent(student);
        Map<String, Object> response = new HashMap<>();
        response.put("message", "Student added successfully!");
        response.put("student", saved);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }
   @GetMapping
    public ResponseEntity<List<student>> getAllStudents() {
        List<student> students = studentService.getAllStudents();
        return new ResponseEntity<>(students, HttpStatus.OK);
   }
   @GetMapping("/{id}")
   public ResponseEntity<student> getStudentById(@PathVariable Long id) {
       student student = studentService.getStudentById(id);
        return new ResponseEntity<>(student, HttpStatus.OK);
    }
    @PutMapping("/{id}")
    public ResponseEntity<Map<String, Object>> updateStudent(
           @PathVariable Long id, @Valid @RequestBody student student) {
        student updated = studentService.updateStudent(id, student);
       Map<String, Object> response = new HashMap<>();
        response.put("message", "Student updated successfully!");
       response.put("student", updated);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
   @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, String>> deleteStudent(@PathVariable Long id) {
        studentService.deleteStudent(id);
        Map<String, String> response = new HashMap<>();
       response.put("message", "Student deleted successfully!");
        return new ResponseEntity<>(response, HttpStatus.OK);
}
}