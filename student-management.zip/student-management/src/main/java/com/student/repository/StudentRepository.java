package com.student.repository;
import com.student.entity.student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;
@Repository

public interface StudentRepository extends JpaRepository<student, Long> {
    List<student> findByIsDeletedFalse();
    Optional<student> findByStudentIdAndIsDeletedFalse(Long studentId);
}
